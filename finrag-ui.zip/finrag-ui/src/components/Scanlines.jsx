import React from "react";

const Scanlines = () => (
  <div className="scanline-overlay" />
);

export default Scanlines;
