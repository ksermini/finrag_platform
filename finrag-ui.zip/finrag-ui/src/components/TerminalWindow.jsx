import React, { useEffect, useState } from "react";
import axios from "axios";

const TerminalWindow = () => {
  const [logs, setLogs] = useState([]);

  const playSound = (src, volume = 1) => {
    const audio = new Audio(src);
    audio.volume = volume;
    audio.play();
  };

  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const res = await axios.get("http://localhost:8000/api/metadata");
        const data = res.data;

        const output = [
          `> query("${data.query}")`,
          `[✓] Retrieved ${data.retrieved_docs_count} documents`,
          `[✓] Model: ${data.model_name} | Latency: ${data.latency_ms}ms`,
          `[✓] Tokens: ${data.tokens_input} in / ${data.tokens_output} out`,
          `[✓] Cached: ${data.cached}`,
          `[✓] Source: ${data.source_type}`,
          `[✓] Timestamp: ${data.timestamp}`,
        ];

        output.forEach((line, i) => {
          setTimeout(() => {
            setLogs((prev) => [...prev, line]);
            playSound("/sounds/key-click.mp3", 0.2);
          }, i * 500);
        });

        setTimeout(() => playSound("/sounds/beep.mp3", 0.3), output.length * 500);

      } catch {
        setLogs(["> error: could not fetch metadata"]);
      }
    };

    fetchMetadata();
  }, []);

  return (
    <div className="text-sm whitespace-pre-wrap leading-relaxed">
      {logs.map((line, i) => (
        <div key={i} className="mb-1">{line}</div>
      ))}
      <div className="animate-blink">_</div>
    </div>
  );
};

export default TerminalWindow;
