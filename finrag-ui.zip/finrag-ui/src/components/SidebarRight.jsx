import React from "react";

const SidebarRight = () => (
  <div className="col-span-2 border-l border-gray-600 p-2 text-[10px] text-right space-y-2">
    <div>SYSTEM STATUS</div>
    <div>Chroma: ONLINE</div>
    <div>DB: CONNECTED</div>
    <div>Requests: 152</div>
    <div>Cache Hits: 45</div>
    <div>Errors: 1</div>
  </div>
);

export default SidebarRight;
