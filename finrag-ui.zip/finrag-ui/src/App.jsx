import React, { useState } from 'react'
import BootScreen from './components/BootScreen'
import TerminalLayout from './components/TerminalLayout'

const App = () => {
  const [bootComplete, setBootComplete] = useState(false)

  return (
    <>
      {!bootComplete && <BootScreen onFinish={() => setBootComplete(true)} />}
      {bootComplete && <TerminalLayout />}
    </>
  )
}

export default App
