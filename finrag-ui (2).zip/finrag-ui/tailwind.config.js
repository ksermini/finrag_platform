/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}'
  ],
  theme: {
    extend: {
      fontFamily: {
        mono: ['VT323', 'monospace'],
      },
      colors: {
        cyan: {
          100: '#a1ffff',
          300: '#00ffff',
          600: '#00bcd4',
          700: '#0097a7'
        },
        gray: {
          400: '#b0bec5',
          500: '#90a4ae',
          700: '#455a64',
          800: '#37474f'
        }
      },
      fontSize: {
        xs: '0.7rem',
        sm: '0.8rem',
        base: '0.9rem'
      }
    }
  },
  safelist: [
    'text-cyan-100', 'text-cyan-300', 'border-cyan-700',
    'text-gray-400', 'bg-gray-800', 'bg-cyan-300',
    'grid-cols-20', 'gap-[1px]', 'w-[2px]', 'h-[2px]'
  ],
  plugins: []
};
