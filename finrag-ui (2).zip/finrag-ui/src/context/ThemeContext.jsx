import React, { createContext, useContext, useEffect, useState } from "react";

// Default theme path from /public
const defaultThemePath = "/themes/tron.json";

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(null);

  // Load default theme on first render
  useEffect(() => {
    loadThemeFromJson(defaultThemePath);
  }, []);

  // Apply CSS variables
  useEffect(() => {
    if (!theme || !theme.colors) return;

    const root = document.documentElement.style;

    root.setProperty("--theme-fg", theme.terminal?.foreground || "#aacfd1");
    root.setProperty("--theme-bg", theme.terminal?.background || "#05080d");
    root.setProperty("--theme-glow", `rgb(${theme.colors.r}, ${theme.colors.g}, ${theme.colors.b})`);
    root.setProperty("--theme-black", theme.colors.black || "#000");

    // Set any other vars from cssvars key
    if (theme.cssvars) {
      Object.entries(theme.cssvars).forEach(([key, value]) => {
        root.setProperty(`--${key}`, value);
      });
    }
  }, [theme]);

  const loadThemeFromJson = async (path) => {
    try {
      const res = await fetch(path);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setTheme(json);
    } catch (err) {
      console.error("Failed to load theme:", err);
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, loadThemeFromJson }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
